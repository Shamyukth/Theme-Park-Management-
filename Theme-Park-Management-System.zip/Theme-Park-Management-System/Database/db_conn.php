<?php


$conn = mysqli_connect("localhost","root","","themepark");

if (!$conn) {

    echo "Connection failed!";
}
